/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package festival.de.cannes;

/**
 *
 * @author johann
 */
public class VIP extends Personne{
    private String nationalite;
    private String metier;
    private String dateNaissance;
    
    /**
     *
     */
    @Override
    public void getPersonne(){
        
    }
    
}
