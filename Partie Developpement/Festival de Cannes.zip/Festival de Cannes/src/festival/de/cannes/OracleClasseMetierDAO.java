/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package festival.de.cannes;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.*;
import javax.sql.DataSource;

/**
 *
 * @author p1511158
 */
public class OracleClasseMetierDAO /*implements IClasseMetierDAO*/{
    private static DataSource ds;
    private static Connection connexionBD;
    //@Override
    public void setDataSource(DataSource ds){
        OracleClasseMetierDAO.ds=ds;
    }
    //@Override
    public void setConnection(Connection c){
        OracleClasseMetierDAO.connexionBD=c;
    }
    //@Override
    public List<ClasseMetier> getLesObjetsClasseMetier(){
        ResultSet rset=null;
        Statement stmt=null;
        List<ClasseMetier> listeClasseMetier=null;
        try{
            stmt=connexionBD.createStatement();
            listeClasseMetier=new ArrayList<>();
            rset=stmt.executeQuery("SELECT * from ClasseMetier ....");
            while(rset.next()){
                //...
            }
        }catch(SQLException exc){
            
        }finally{
            try{
                //la clause finally est toujours executee, quoi qu'il arrive
                if(stmt!=null)stmt.close();
                if(rset!=null)rset.close();
            }catch(SQLException ex){
                
            }
        }
        return listeClasseMetier;
    }
    
}
