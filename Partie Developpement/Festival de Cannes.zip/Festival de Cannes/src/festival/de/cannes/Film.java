/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package festival.de.cannes;

/**
 *Retourne les films de la BDD
 * 
 * @author johann
 */
public class Film {
    private int duree;
    private int numFilm;
    private String realisateur;
    
    public void getFilm(){
        
    }
    
}
